package com.example.intentopennextscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /* Called when the user taps the Send button */
    public void sendMessage(View view) {

        /* Creating instance of Intent object */
        Intent intent = new Intent(this, DisplayMessageActivity.class);

        /* finding the user-input provided in the editText as an object  */
        EditText editText = (EditText) findViewById(R.id.editText1);

        /* converting the user-input of editText as String  */
        String message = editText.getText().toString();

        /* sending the message to other activity as Key-Value Pair */
		intent.putExtra("Value", message);

        /* starting the intent */
        startActivity(intent);
    }
}
